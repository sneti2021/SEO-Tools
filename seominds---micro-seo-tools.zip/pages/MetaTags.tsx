import React, { useState } from 'react';
import { generateMetaTags } from '../services/geminiService';
import { MetaTagResponse } from '../types';

const MetaTags: React.FC = () => {
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MetaTagResponse | null>(null);

  const handleGenerate = async () => {
    if (!content.trim()) return;
    setLoading(true);
    try {
      const data = await generateMetaTags(content);
      setResult(data);
    } catch (err) {
      alert('Generation failed.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  return (
    <div className="max-w-5xl mx-auto">
      <section className="mb-16">
        <div className="mb-8 text-center max-w-3xl mx-auto">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Free AI Meta Tag Generator</h1>
          <p className="text-lg text-gray-600">
            Instantly generate SEO-optimized Title tags, Meta Descriptions, and OpenGraph social media tags for your website to boost click-through rates.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Input Section */}
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 h-fit">
            <label className="block text-sm font-bold text-gray-700 mb-2">Page Content or Product Description</label>
            <textarea
              className="w-full h-48 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none resize-none mb-6 transition-all text-gray-700"
              placeholder="Paste your blog post, product description, or landing page copy here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            <button
              onClick={handleGenerate}
              disabled={loading || !content}
              className={`w-full py-4 rounded-lg font-bold text-white text-lg transition-all flex justify-center items-center gap-2 shadow-md ${
                loading || !content ? 'bg-gray-300 cursor-not-allowed' : 'bg-orange-600 hover:bg-orange-700 hover:shadow-lg transform active:scale-99'
              }`}
            >
              {loading ? (
                  <>
                     <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                     Creating Tags...
                  </>
              ) : 'Generate Tags'}
            </button>
          </div>

          {/* Output Section */}
          <div className="space-y-6">
            {result ? (
              <>
                {/* Title Tag */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 group hover:border-orange-400 transition-colors animate-fade-in border-l-4 border-l-orange-500">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wide">Title Tag</h3>
                    <button onClick={() => copyToClipboard(result.title)} className="text-orange-600 hover:text-orange-800 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">COPY</button>
                  </div>
                  <p className="text-gray-900 font-bold text-lg">{result.title}</p>
                  <div className="mt-2 text-xs text-gray-400 text-right">{result.title.length} / 60 chars</div>
                </div>

                {/* Description */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 group hover:border-orange-400 transition-colors animate-fade-in border-l-4 border-l-orange-500" style={{animationDelay: '0.1s'}}>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wide">Meta Description</h3>
                    <button onClick={() => copyToClipboard(result.description)} className="text-orange-600 hover:text-orange-800 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">COPY</button>
                  </div>
                  <p className="text-gray-700 text-base leading-relaxed">{result.description}</p>
                  <div className="mt-2 text-xs text-gray-400 text-right">{result.description.length} / 160 chars</div>
                </div>

                 {/* OpenGraph Preview */}
                 <div className="bg-gray-100 rounded-xl p-6 border border-gray-200 animate-fade-in" style={{animationDelay: '0.2s'}}>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-4">Social Preview</h3>
                    <div className="bg-white rounded-lg border border-gray-300 overflow-hidden max-w-sm mx-auto shadow-sm">
                        <div className="h-40 bg-gray-200 flex items-center justify-center text-gray-400 text-sm font-medium">Image Preview</div>
                        <div className="p-4 bg-gray-50 border-t border-gray-200">
                          <div className="uppercase text-xs text-gray-500 mb-1">YOURWEBSITE.COM</div>
                          <div className="font-bold text-gray-900 truncate mb-1 text-base">{result.ogTitle || result.title}</div>
                          <div className="text-xs text-gray-600 line-clamp-2">{result.ogDescription || result.description}</div>
                        </div>
                    </div>
                 </div>
              </>
            ) : (
               <div className="h-full bg-gray-50 rounded-xl border border-dashed border-gray-300 flex items-center justify-center text-gray-400 min-h-[300px]">
                  <span className="text-lg font-medium">Generated tags will appear here</span>
               </div>
            )}
          </div>
        </div>
      </section>

      {/* Extensive Content Section */}
      <section className="prose prose-lg max-w-none text-gray-700">
        <div className="grid lg:grid-cols-3 gap-12">
          
          <div className="lg:col-span-2 space-y-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Optimize Your Site with AI</h2>
              <p className="mb-4">
                Your <strong>SEO title</strong> and meta description are your first impression in search engine results pages (SERPs). A compelling title encourages users to click, while a well-crafted description provides context.
              </p>
              
              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Maximize Click-Through Rates (CTR)</h3>
              <p className="mb-4">
                A high CTR tells Google your page is relevant. Our <em>meta tag generator</em> crafts optimized copy designed to capture attention and drive organic traffic by using power words and clear value propositions.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Social Media Optimization</h3>
              <p className="mb-4">
                When your link is shared on Facebook, Twitter (X), or LinkedIn, the platform looks for <strong>Open Graph (OG) tags</strong>. Without these, your link looks broken. Our tool automatically generates these tags to ensure your content looks professional everywhere.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Smart Keyword Integration</h3>
              <p>
                Keyword stuffing is bad. Our AI analyzes your content to naturally extract and integrate primary keywords into your <em>meta descriptions</em> and titles, ensuring perfect alignment with user search intent without looking spammy.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">BEST PRACTICES</h2>
              <ul className="space-y-4 list-none pl-0">
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Title Length</strong>
                    Keep it between 50-60 characters to prevent truncation in Google results.
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Description Length</strong>
                    Aim for 150-160 characters. It should act as a mini-ad for your page.
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Call to Action</strong>
                    Use words like "Learn," "Buy," "Discover," or "Free" to entice clicks.
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Do meta keywords still matter?</h4>
                  <p className="text-sm text-gray-600 mt-1">No. Google stopped using the "meta keywords" tag for ranking years ago. Focus on Title and Description.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Why does Google rewrite my descriptions?</h4>
                  <p className="text-sm text-gray-600 mt-1">Google may ignore your description if it thinks a snippet from your page content answers the user's query better.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Is this tool free?</h4>
                  <p className="text-sm text-gray-600 mt-1">Yes, you can generate unlimited meta tags for free using our AI-powered tool.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
};

export default MetaTags;