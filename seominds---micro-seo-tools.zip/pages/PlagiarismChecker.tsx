import React, { useState, useEffect } from 'react';
import { checkPlagiarism } from '../services/geminiService';
import { PlagiarismResponse } from '../types';

const PlagiarismChecker: React.FC = () => {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('Scanning Web...');
  const [result, setResult] = useState<PlagiarismResponse | null>(null);

  useEffect(() => {
    let interval: any;
    if (loading) {
      const texts = ['Scanning Web...', 'Comparing Sources...', 'Analyzing Similarity...', 'Finalizing Report...'];
      let i = 0;
      interval = setInterval(() => {
        i = (i + 1) % texts.length;
        setLoadingText(texts[i]);
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleCheck = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setResult(null);
    try {
      const data = await checkPlagiarism(text);
      setResult(data);
    } catch (err) {
      // Error is handled in service, but we catch just in case
      alert('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <section className="mb-16">
        <div className="mb-8 text-center max-w-3xl mx-auto">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Free Online Plagiarism Checker</h1>
          <p className="text-lg text-gray-600">
            Paste your text below to check for potential duplicate content across the web using Google Search grounding technology. 
            Ensure your content is original and SEO-friendly.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 mb-8 transition-shadow hover:shadow-xl">
          <textarea
            className="w-full h-64 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none transition-all text-gray-700 leading-relaxed"
            placeholder="Paste your article, essay, or web content here to scan for plagiarism (min 50 characters)..."
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="mt-4 flex flex-col sm:flex-row justify-between items-center gap-4">
              <span className="text-sm font-medium text-gray-500">{text.length} characters</span>
              <button
              onClick={handleCheck}
              disabled={loading || text.length < 50}
              className={`w-full sm:w-auto px-8 py-3 rounded-lg font-bold text-white text-lg transition-all transform active:scale-95 shadow-md ${
                  loading || text.length < 50
                  ? 'bg-gray-300 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 hover:shadow-lg'
              }`}
              >
              {loading ? (
                  <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      {loadingText}
                  </span>
              ) : 'Check Plagiarism'}
              </button>
          </div>
        </div>

        {result && (
          <div className="animate-fade-in bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden mb-12">
              <div className="p-6 border-b border-gray-100 bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <h3 className="text-xl font-bold text-gray-800">Analysis Report</h3>
                  <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
                      <span className="text-sm font-bold text-gray-500 uppercase">Uniqueness Score</span>
                      <span className={`text-3xl font-black ${result.score < 20 ? 'text-green-600' : result.score < 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                          {100 - result.score}%
                      </span>
                  </div>
              </div>
              
              <div className="p-8">
                  <div className="mb-8">
                      <h4 className="text-lg font-bold text-gray-900 mb-3">Summary</h4>
                      <p className="text-gray-700 bg-blue-50 p-5 rounded-lg border border-blue-100 leading-relaxed">
                          {result.analysis}
                      </p>
                  </div>

                  <div>
                      <h4 className="text-lg font-bold text-gray-900 mb-4">Detailed Matches</h4>
                      {result.matches.length === 0 ? (
                           <div className="text-center py-10 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                             <svg className="w-12 h-12 text-green-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                             <p className="text-gray-600 font-medium">No significant plagiarism found. Your content appears unique!</p>
                           </div>
                      ) : (
                          <div className="space-y-4">
                              {result.matches.map((match, idx) => (
                                  <div key={idx} className="group border-l-4 border-red-500 bg-red-50 p-5 rounded-r-lg hover:bg-red-100 transition-colors">
                                      <p className="text-gray-900 font-medium mb-2 italic">"{match.text}"</p>
                                      <div className="flex items-center gap-2 mt-3">
                                          <span className="text-xs font-bold text-red-600 uppercase tracking-wide bg-red-200 px-2 py-1 rounded">Source</span>
                                          <a href={match.source} target="_blank" rel="noreferrer" className="text-sm text-blue-700 hover:underline truncate flex-1 font-medium">
                                              {match.source}
                                          </a>
                                      </div>
                                  </div>
                              ))}
                          </div>
                      )}
                  </div>
              </div>
          </div>
        )}
      </section>

      {/* Extensive Content Section */}
      <section className="prose prose-lg max-w-none text-gray-700">
        <div className="grid lg:grid-cols-3 gap-12">
          
          <div className="lg:col-span-2 space-y-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Benefits of SmallSEOTools’ Plagiarism Detector</h2>
              <p className="mb-4">
                The plagiarism checker free utility offered on SeoMinds is second to none due to the advantages it provides to its users. From students to teachers, researchers, writers, publishers, and bloggers, everyone can gain the top benefits of our plagiarism detector, which include the following:
              </p>
              
              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Quick and Hassle-Free</h3>
              <p className="mb-4">
                The plagiarism checker online tool available on this platform is a super-fast utility that generates results within a matter of seconds. For using this plagiarism detector, the users won’t have to follow any convoluted procedure. The user-friendly interface of this facility makes the process to check plagiarism free from all kinds of intricacies.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Multi-Platform Supportive</h3>
              <p className="mb-4">
                Our plagiarism detector is a web-based tool that can be accessed through any kind of device. You won’t have to install a plugin or software for checking duplication with this plagiarism checker online utility. Whether you have an Android, iOS, Windows, Linux, or Mac device, you can easily access our online plagiarism remover and figure out the instances of plagiarism in a couple of clicks.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Find Matching Sources</h3>
              <p>
                When it comes to detecting plagiarism, everybody desires to know about the links from where their text matches. The best free plagiarism checker by SeoMinds not only detects the plagiarized portions of your text but also provides you with a list of sources from where your entered text is matching.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">FEATURES OF OUR PLAGIARISM CHECKER</h2>
              <ul className="space-y-4 list-none pl-0">
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Billions of web pages</strong>
                    This tool has the ability to check plagiarism by matching your content against billions of webpages on the Internet. Once you upload your content, it will automatically run it against every existing content on the web.
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Percentage gauges</strong>
                    Our duplication checker will show you, in percentages, the levels of both plagiarized and unique content in the document. For example, it'll let you know that 82% of the content is unique while 18% is plagiarized.
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">A list-based, sentence-wise result</strong>
                    The tool shows you, in a list format for easy detection, both plagiarized and unique areas of the content piece. Plagiarized sentences are highlighted for your convenience.
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-1">✓</div>
                  <div>
                    <strong className="block text-gray-900">Privacy Guaranteed</strong>
                    We respect user privacy, and hence do not save your content in our system. Once the tool is done running the plagiarism check on your content, it automatically deletes it from our system immediately.
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">What is the word limit to check plagiarism?</h4>
                  <p className="text-sm text-gray-600 mt-1">Our free tool currently supports checking up to 2,000 characters per search to ensure fast processing for all users.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Who Uses SeoMinds’ Plagiarism Checker?</h4>
                  <p className="text-sm text-gray-600 mt-1">People involved in any kind of writing task love using our tool. Students rely on this tool for finding sources. Teachers find this tool useful for identifying plagiarism from work submitted by their students.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Does My Content Remain Secure?</h4>
                  <p className="text-sm text-gray-600 mt-1">Yes! Our tool makes sure to keep its users’ content 100% safe. We do not store or sell your data.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Why Should I Use a Plagiarism Checker Free?</h4>
                  <p className="text-sm text-gray-600 mt-1">Due to the heavy workload, people aren’t left with enough time to detect and remove plagiarism manually. This tool generates a report instantaneously.</p>
                </div>
              </div>
            </div>
          </div>

        </div>

        <div className="mt-16 bg-blue-900 text-white rounded-2xl p-8 sm:p-12 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Check Your Content?</h2>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto text-lg">
            Don't let duplicate content damage your reputation or SEO rankings. Use our advanced AI-powered tool today for free.
          </p>
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="bg-white text-blue-900 px-8 py-3 rounded-lg font-bold hover:bg-blue-50 transition-colors"
          >
            Check Plagiarism Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default PlagiarismChecker;