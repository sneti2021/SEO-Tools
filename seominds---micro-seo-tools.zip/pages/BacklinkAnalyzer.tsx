import React, { useState } from 'react';
import { analyzeBacklinkOpportunities } from '../services/geminiService';
import { BacklinkOpportunity } from '../types';

const BacklinkAnalyzer: React.FC = () => {
  const [url, setUrl] = useState('');
  const [keyword, setKeyword] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<BacklinkOpportunity[]>([]);

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url || !keyword) return;
    setLoading(true);
    try {
      const data = await analyzeBacklinkOpportunities(url, keyword);
      setResults(data);
    } catch (err) {
      alert('Error fetching backlink opportunities.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <section className="mb-16">
        <div className="text-center mb-10 max-w-3xl mx-auto">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-4">Free Backlink Strategy Analyzer</h1>
          <p className="text-lg text-gray-600">
            Discover high-quality guest posting and link-building opportunities tailored to your specific niche using AI-powered search analysis.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-8 mb-10">
          <form onSubmit={handleAnalyze} className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Your Website URL</label>
              <input
                type="url"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none transition-all"
                placeholder="https://example.com"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Target Keyword / Niche</label>
              <input
                type="text"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none transition-all"
                placeholder="e.g. Organic Coffee, SaaS Marketing"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
              />
            </div>
            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={loading}
                className={`w-full py-4 rounded-lg font-bold text-white text-lg transition-all shadow-md ${
                  loading ? 'bg-green-400' : 'bg-green-600 hover:bg-green-700 hover:shadow-lg transform active:scale-99'
                }`}
              >
                {loading ? 'Scouting Opportunities...' : 'Find Backlink Opportunities'}
              </button>
            </div>
          </form>
        </div>

        {results.length > 0 && (
          <div className="animate-fade-in mb-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Recommended Opportunities</h2>
            <div className="grid grid-cols-1 gap-6">
              {results.map((opp, idx) => (
                <div key={idx} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:border-green-400 transition-colors border-l-4 border-l-green-500">
                  <div className="flex-grow">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold text-gray-800">{opp.siteName}</h3>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${
                        opp.authority === 'High' ? 'bg-green-100 text-green-700' :
                        opp.authority === 'Medium' ? 'bg-blue-100 text-blue-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {opp.authority} Auth
                      </span>
                    </div>
                    <a href={opp.url} target="_blank" rel="noreferrer" className="text-sm text-green-600 hover:underline mb-2 block truncate max-w-lg font-medium">
                      {opp.url}
                    </a>
                    <p className="text-gray-600 text-sm">{opp.relevance}</p>
                  </div>
                  <div className="flex-shrink-0">
                    <a 
                      href={opp.url} 
                      target="_blank" 
                      rel="noreferrer"
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none transition-colors"
                    >
                      Visit Site
                      <svg className="ml-2 -mr-1 h-4 w-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                      </svg>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Extensive Content Section */}
      <section className="prose prose-lg max-w-none text-gray-700">
        <div className="grid lg:grid-cols-3 gap-12">
          
          <div className="lg:col-span-2 space-y-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Master Your Link Building Strategy</h2>
              <p className="mb-4">
                Backlinks (inbound links) remain one of the top three ranking factors for Google. They act as "votes of confidence" from other websites. The more high-quality <strong>backlinks</strong> your site has, the more trustworthy it appears to search engines, leading to higher rankings and increased organic traffic.
              </p>
              
              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Quality vs. Quantity</h3>
              <p className="mb-4">
                Gone are the days of spamming thousands of low-quality directory links. Modern SEO demands <em>contextual relevance</em> and authority. A single link from a respected blog in your industry is worth more than 100 links from unrelated sites. Our <strong>backlink checker</strong> focuses on finding these "gold nugget" opportunities.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Automate Your Outreach Research</h3>
              <p className="mb-4">
                Prospecting for guest posts or resource pages is time-consuming. SeoMinds leverages AI to scan search results for your target keywords, identifying blogs, forums, and news sites that are likely to link to you. This streamlines your <strong>link building campaign</strong> and lets you focus on crafting the perfect pitch.
              </p>

              <h3 className="text-xl font-bold text-gray-800 mt-6 mb-3">Competitor Analysis</h3>
              <p>
                To outrank your competitors, you need to understand where they get their links. By using our tool with keywords related to your competitors, you can uncover the specific websites that might also link to you.
              </p>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">HOW TO USE EFFECTIVELY</h2>
              <ol className="space-y-4 list-decimal pl-5">
                <li>
                  <strong className="text-gray-900">Enter Your URL:</strong> This helps the AI understand your site's context.
                </li>
                <li>
                  <strong className="text-gray-900">Define Your Niche:</strong> Be specific. Instead of just "fitness", try "home workout equipment reviews". Specificity yields better prospects.
                </li>
                <li>
                  <strong className="text-gray-900">Analyze Results:</strong> Look at the "Relevance" and "Authority" tags. High authority sites are valuable targets.
                </li>
                <li>
                  <strong className="text-gray-900">Take Action:</strong> Visit the sites, look for "Write for Us" pages, and pitch your content.
                </li>
              </ol>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200 sticky top-24">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h3>
              <div className="space-y-6">
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">What is Domain Authority (DA)?</h4>
                  <p className="text-sm text-gray-600 mt-1">DA is a search engine ranking score that predicts how likely a website is to rank on SERPs. Higher is better.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Are these links safe?</h4>
                  <p className="text-sm text-gray-600 mt-1">Yes, because this tool only suggests opportunities for "White Hat" outreach. You are not buying links.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">Does this tool build links automatically?</h4>
                  <p className="text-sm text-gray-600 mt-1">No. Automated link building is dangerous and can get you penalized. We help you find the opportunities so you can build real relationships.</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
};

export default BacklinkAnalyzer;