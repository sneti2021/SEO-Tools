import { GoogleGenAI, Type } from "@google/genai";
import { AiDetectorResponse, BacklinkOpportunity, MetaTagResponse, PlagiarismResponse } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to safely parse JSON from text which might contain markdown or extra text
const cleanJson = (text: string) => {
  if (!text) return '{}';
  try {
    // 1. Try to find markdown code block
    const match = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (match) return match[1];

    // 2. If no markdown, try to find the first '{' and last '}' to extract the object
    const firstOpen = text.indexOf('{');
    const lastClose = text.lastIndexOf('}');
    if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
      return text.substring(firstOpen, lastClose + 1);
    }
    
    // 3. Fallback to original text (might be raw JSON)
    return text;
  } catch (e) {
    return text;
  }
};

export const checkPlagiarism = async (text: string): Promise<PlagiarismResponse> => {
  try {
    const model = "gemini-3-flash-preview";
    const prompt = `
      Act as a plagiarism detection engine. Analyze the following text.
      Use Google Search to cross-reference phrases and sentences to find potential duplicates online.
      
      Text to analyze: "${text.substring(0, 2000)}"

      You MUST return a valid JSON object string. Do not use markdown code blocks or explanations outside the JSON.
      JSON Format:
      {
        "score": number (0-100, where 100 is fully plagiarized),
        "analysis": "A brief summary of findings",
        "matches": [
          { "text": "The specific phrase found", "source": "URL or Source Name" }
        ]
      }
    `;

    // Note: Removed responseSchema and responseMimeType when using tools to ensure stability
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    const cleanText = cleanJson(response.text || '{}');
    let parsed: any = {};
    try {
        parsed = JSON.parse(cleanText);
    } catch (e) {
        console.warn("Failed to parse JSON", e);
        // Fallback if parsing fails but we got text
        return {
            score: 0,
            analysis: response.text || "Analysis completed but format was invalid.",
            matches: []
        };
    }

    return {
        score: typeof parsed.score === 'number' ? parsed.score : 0,
        analysis: parsed.analysis || "Analysis complete.",
        matches: Array.isArray(parsed.matches) ? parsed.matches : []
    };
  } catch (error) {
    console.error("Plagiarism check failed", error);
    return {
        score: 0,
        analysis: "The service is currently unavailable. Please check your internet connection or try again later.",
        matches: []
    };
  }
};

export const detectAiContent = async (text: string): Promise<AiDetectorResponse> => {
  try {
    const model = "gemini-3-flash-preview";
    const prompt = `
      Analyze the following text for linguistic patterns, perplexity, and burstiness typical of AI-generated content vs Human-written content.
      
      Text: "${text.substring(0, 3000)}"
      
      Return JSON only:
      {
        "aiScore": number (0-100 probability of being AI),
        "verdict": "Human" | "AI" | "Mixed",
        "reasoning": "Detailed explanation of why",
        "highlightedSections": ["List of suspicious sentences"]
      }
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                aiScore: { type: Type.NUMBER },
                verdict: { type: Type.STRING, enum: ["Human", "AI", "Mixed"] },
                reasoning: { type: Type.STRING },
                highlightedSections: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
        }
      }
    });
    
    const cleanText = cleanJson(response.text || '{}');
    let parsed: any = {};
    try {
        parsed = JSON.parse(cleanText);
    } catch (e) {
        console.warn("Failed to parse JSON", e);
    }

    return {
        aiScore: typeof parsed.aiScore === 'number' ? parsed.aiScore : 0,
        verdict: parsed.verdict || 'Human',
        reasoning: parsed.reasoning || "Unable to determine reasoning.",
        highlightedSections: Array.isArray(parsed.highlightedSections) ? parsed.highlightedSections : []
    };
  } catch (error) {
    console.error("AI detection failed", error);
    return {
        aiScore: 0,
        verdict: 'Human',
        reasoning: "Service error. Please try again.",
        highlightedSections: []
    };
  }
};

export const analyzeBacklinkOpportunities = async (url: string, keyword: string): Promise<BacklinkOpportunity[]> => {
  try {
    const model = "gemini-3-flash-preview";
    const prompt = `
      I want to build backlinks for the following URL: ${url}
      Target Keyword/Niche: ${keyword}

      Use Google Search to find 5 high-quality websites, blogs, or forums where I could potentially get a backlink (e.g., guest posts, resource pages, forums).
      
      You MUST return a JSON array of objects.
      Format:
      [
        { "siteName": "Name", "url": "URL", "relevance": "Why it fits", "authority": "High/Medium/Low" }
      ]
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        // Removed strict schema enforcement to allow tool usage flexibility
      }
    });

    const cleanText = cleanJson(response.text || '[]');
    let parsed = [];
    try {
        parsed = JSON.parse(cleanText);
    } catch (e) {
        console.warn("Failed to parse JSON", e);
    }
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error("Backlink analysis failed", error);
    return [];
  }
};

export const generateMetaTags = async (content: string): Promise<MetaTagResponse> => {
  try {
    const model = "gemini-3-flash-preview";
    const prompt = `
      Generate SEO optimized meta tags for the following content/description.
      
      Content: "${content.substring(0, 1000)}"
      
      Return JSON only:
      {
        "title": "SEO Title (under 60 chars)",
        "description": "Meta Description (under 160 chars)",
        "keywords": ["tag1", "tag2"],
        "ogTitle": "OpenGraph Title",
        "ogDescription": "OpenGraph Description"
      }
    `;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                ogTitle: { type: Type.STRING },
                ogDescription: { type: Type.STRING }
            }
        }
      }
    });

    const cleanText = cleanJson(response.text || '{}');
    let parsed: any = {};
    try {
        parsed = JSON.parse(cleanText);
    } catch (e) {
        console.warn("Failed to parse JSON", e);
    }

    return {
        title: parsed.title || "Error Generating Title",
        description: parsed.description || "Error generating description",
        keywords: Array.isArray(parsed.keywords) ? parsed.keywords : [],
        ogTitle: parsed.ogTitle || "",
        ogDescription: parsed.ogDescription || ""
    };
  } catch (error) {
    console.error("Meta generation failed", error);
    return {
        title: "Error",
        description: "Service unavailable",
        keywords: [],
        ogTitle: "",
        ogDescription: ""
    };
  }
};