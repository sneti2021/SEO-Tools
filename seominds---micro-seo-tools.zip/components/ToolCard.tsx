import React from 'react';
import { Link } from 'react-router-dom';

interface ToolCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  to: string;
  colorClass: string;
}

const ToolCard: React.FC<ToolCardProps> = ({ title, description, icon, to, colorClass }) => {
  return (
    <Link to={to} className="group block h-full">
      <div className="bg-white rounded-2xl border border-gray-200 p-6 h-full transition-all duration-300 hover:shadow-xl hover:border-transparent hover:-translate-y-1 relative overflow-hidden">
        <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full opacity-10 transition-transform group-hover:scale-150 ${colorClass}`}></div>
        
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorClass} bg-opacity-10 text-opacity-100`}>
          <div className={colorClass.replace('bg-', 'text-').replace('bg-opacity-10', '')}>
             {icon}
          </div>
        </div>
        
        <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">{title}</h3>
        <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
        
        <div className="mt-4 flex items-center text-sm font-medium text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
          Launch Tool &rarr;
        </div>
      </div>
    </Link>
  );
};

export default ToolCard;
