import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path ? 'text-blue-600 bg-blue-50' : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">S</div>
                <span className="font-bold text-xl text-slate-900 tracking-tight">SeoMinds</span>
              </Link>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link to="/" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive('/')}`}>Dashboard</Link>
              <Link to="/plagiarism" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive('/plagiarism')}`}>Plagiarism</Link>
              <Link to="/detector" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive('/detector')}`}>AI Detector</Link>
              <Link to="/backlinks" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive('/backlinks')}`}>Backlinks</Link>
              <Link to="/metatags" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${isActive('/metatags')}`}>Meta Tags</Link>
            </nav>
            <div className="md:hidden">
              {/* Mobile menu button could go here */}
              <span className="text-gray-400 text-xs">v1.0</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} SeoMinds. Powered by Google Gemini.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
